
<?php
class Api_model extends CI_Model
{
 function fetch_all($where=array())
 {
 	if(!empty($where['urole'])){
 	$this->db->where($where);
 }
  $this->db->order_by('created_on', 'DESC');
  $this->db->select('u.*,r.role_type')->from('user_details AS u');
  $this->db->join('user_role_type AS r','u.urole=r.role_id','left');
  return $this->db->get();
 }

 function insert_api($data)
 {
  $this->db->insert('user_details', $data);
  if($this->db->affected_rows() > 0)
  {
   return true;
  }
  else
  {
   return false;
  }
 }

 function fetch_single_user($user_id)
 {
  $this->db->where("user_id", $user_id);
  $this->db->select('u.*,r.role_type')->from('user_details AS u');
  $this->db->join('user_role_type AS r','u.urole=r.role_id','left');
  $query=$this->db->get();
  //$query = $this->db->get('user_details');
  return $query->result_array();
 }
 function update_api($user_id, $data)
 {
  $this->db->where("user_id", $user_id);
  $this->db->update("user_details", $data);
 //echo $this->db->last_query();die;
 }
 
 function delete_single_user($user_id)
 {
  $this->db->where("user_id", $user_id);
  $this->db->delete("user_details");
  if($this->db->affected_rows() > 0)
  {
   return true;
  }
  else
  {
   return false;
  }
 }

 function getDropDownArr($table_name,$key,$val,$where=''){
 	$dataArr=array();
 	if(!empty($where)){
 		$this->db->where($where);
 	}
 	$response = $this->db->select($key.','.$val)->from($table_name)->get()->result_array();
 	if(count($response) > 0){
 		foreach ($response as $rkey => $rval) {
 			$dataArr[$rval['role_id']]=$rval['role_type'];
 			# code...
 		}

 	}
 	//echo '<pre>';print_r($dataArr);die;
 	return $dataArr;
 }


 function checkDuplicateCount($where){
  $count=0;

  $this->db->where($where);
  $query=$this->db->select('count(*) AS row')->from('user_details')->get()->row_array();
  //echo $this->db->last_query();
  
  
  if(isset($query['row'])){
    $count=$query['row'];
    //return $count;

  }
//echo $count;die;
return $count;
 }
}