
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {

 public function __construct()
 {
  parent::__construct();
  $this->load->model('api_model');
  $this->load->library('form_validation');
  
 }

 function index()
 {
 	$where=array('urole'=>$this->input->post('role_type'));
  $data = $this->api_model->fetch_all($where);
  //echo $this->db->last_query();die;
  echo json_encode($data->result_array());
 }
 
 function insert()
 {
  $this->form_validation->set_rules("first_name", "First Name", "required");
  $this->form_validation->set_rules("last_name", "Last Name", "required");
  $array = array();
  if($this->form_validation->run())
  {
   $data = array(
    'fname' => trim($this->input->post('first_name')),
    'lname'  => trim($this->input->post('last_name')),
     'mname'=>trim($this->input->post('middle_name')),
    'uemail'=>trim($this->input->post('uemail')),
    'upass'=>trim($this->input->post('upass')),
    'urole'=>trim($this->input->post('urole')),
    'phone_no'=>trim($this->input->post('phone_no')),
   );
   $this->api_model->insert_api($data);
   $array = array(
    'success'  => true
   );
  }
  else
  {
   $array = array(
    'error'    => true,
    'first_name_error' => form_error('first_name'),
    'last_name_error' => form_error('last_name'),
     'middle_name'=>trim($this->input->post('middle_name')),
    'uemail'=>trim($this->input->post('uemail')),
    'upass'=>trim($this->input->post('upass')),
    'urole'=>trim($this->input->post('urole')),
    'phone_no'=>trim($this->input->post('phone_no')),
   );
  }
  echo json_encode($array, true);
 }

 function fetch_single()
 {
  if($this->input->post('id'))
  {
   $data = $this->api_model->fetch_single_user($this->input->post('id'));
   foreach($data as $row)
   {
    $output['first_name'] = $row["fname"];
    $output['last_name'] = $row["lname"];
    $output['middle_name'] = $row["mname"];
    $output['email'] = $row["uemail"];
    $output['pass'] = $row["upass"];
    $output['role_type'] = $row["urole"];
    $output['phone_no']=$row["phone_no"];
   }
   echo json_encode($output);
  }
 }

 function update()
 {
  $this->form_validation->set_rules("first_name", "First Name", "required");
  $this->form_validation->set_rules("last_name", "Last Name", "required");
  $array = array();
  if($this->form_validation->run())
  {
   $data = array(
    'fname' => trim($this->input->post('first_name')),
    'lname'  => trim($this->input->post('last_name')),
    'mname'=>trim($this->input->post('middle_name')),
    'uemail'=>trim($this->input->post('uemail')),
    'upass'=>trim($this->input->post('upass')),
    'urole'=>trim($this->input->post('urole')),
    'phone_no'=>trim($this->input->post('phone_no')),
   );
   $this->api_model->update_api($this->input->post('id'), $data);
   $array = array(
    'success'  => true
   );
  }
  else
  {
   $array = array(
    'error'    => true,
    'first_name_error' => form_error('first_name'),
    'last_name_error' => form_error('last_name')
   );
  }
  echo json_encode($array, true);
 }

 function delete()
 {
  if($this->input->post('id'))
  {
   if($this->api_model->delete_single_user($this->input->post('id')))
   {
    $array = array(
     'success' => true
    );
   }
   else
   {
    $array = array(
     'error' => true
    );
   }
   echo json_encode($array);
  }
 }
 
}