
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test_api extends CI_Controller {

public $flag=1;
	public function __construct(){
   
		parent::__construct();
		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->model('Api_model','AM');
     if($this->flag == 0){
      redirect(base_url('error'));
    }
	}

  public function access($recFlag=1){
    $this->flag=$recFlag;
     if($this->flag == 0){
        redirect(base_url('error'));
      }
      return true;
}

 function index()
 {
  //print_r($this->input->post());
  $this->access(1);
 	$data['role_type_list']=$this->AM->getDropDownArr('user_role_type','role_id','role_type');
 	$data['selected_role_type']=$this->input->post('role_type');
  $this->load->view('api_view',$data);
}

function action()
{
   $this->access($this->input->post('flag'));
  if($this->input->post('data_action'))
  {
   $data_action = $this->input->post('data_action');

   if($data_action == "Delete")
   {
    $api_url = base_url("api/delete");

    $form_data = array(
     'id'  => $this->input->post('user_id')
   );

    $client = curl_init($api_url);

    curl_setopt($client, CURLOPT_POST, true);

    curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($client);

    curl_close($client);

    echo $response;




  }

  if($data_action == "Edit")
  {
    $api_url = base_url("api/update");

    $form_data = array(
     'first_name'  => $this->input->post('first_name'),
     'last_name'   => $this->input->post('last_name'),
     'id'    => $this->input->post('user_id'),
     'middle_name'=>trim($this->input->post('middle_name')),
     'uemail'=>trim($this->input->post('uemail')),
     'upass'=>trim($this->input->post('upass')),
     'urole'=>trim($this->input->post('urole')),
     'phone_no'=>trim($this->input->post('phone_no')),
   );

    $client = curl_init($api_url);

    curl_setopt($client, CURLOPT_POST, true);

    curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($client);

    curl_close($client);

    echo $response;







  }

  if($data_action == "fetch_single")
  {
    $api_url = base_url("api/fetch_single");

    $form_data = array(
     'id'  => $this->input->post('user_id')
   );

    $client = curl_init($api_url);

    curl_setopt($client, CURLOPT_POST, true);

    curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($client);

    curl_close($client);

    echo $response;






  }

  if($data_action == "Insert")
  {
    $api_url = base_url("api/insert");


    $form_data = array(
     'first_name'  => $this->input->post('first_name'),
     'last_name'   => $this->input->post('last_name'),
     'middle_name'=>trim($this->input->post('middle_name')),
     'uemail'=>trim($this->input->post('uemail')),
     'upass'=>trim($this->input->post('upass')),
     'urole'=>trim($this->input->post('urole')),
     'phone_no'=>trim($this->input->post('phone_no')),
   );

    $client = curl_init($api_url);

    curl_setopt($client, CURLOPT_POST, true);

    curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($client);

    curl_close($client);

    echo $response;


  }





  if($data_action == "fetch_all")
  {
    $api_url = base_url("api");
    $form_data = array(
     'role_type'  => $this->input->post('role_type'),
     
   );

    $client = curl_init($api_url);

    curl_setopt($client, CURLOPT_POST, true);

    curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

    // $client = curl_init($api_url);

    // curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($client);

    curl_close($client);

    $result = json_decode($response);

    $output = '';

    if(count($result) > 0)
    {
     foreach($result as $row)
     {
      $output .= '
      <tr>
      <td>'.$row->fname.'</td>
      <td>'.$row->mname.'</td>
      <td>'.$row->lname.'</td>
      <td>'.$row->phone_no.'</td>
      <td>'.$row->uemail.'</td>
      <td>'.$row->upass.'</td>
      <td>'.$row->role_type.'</td>
      <td><butto type="button" name="edit" class="btn btn-warning btn-xs edit" id="'.$row->user_id.'">Edit</button></td>
      <td><button type="button" name="delete" class="btn btn-danger btn-xs delete" id="'.$row->user_id.'">Delete</button></td>
      </tr>

      ';
    }
  }
  else
  {
   $output .= '
   <tr>
   <td colspan="9" align="center">No Data Found</td>
   </tr>
   ';
 }

 echo $output;
}
}
}


function check_duplicate_phone(){
  $message['exist']='';
  $data=array('phone_no'=>$this->input->post('phone'));
  $count=$this->AM->checkDuplicateCount($data);
  if($count>0){
   $message['exist']='yes';

 }else{
  $message['exist']='no';
}

echo json_encode($message);
}


function check_duplicate_email(){
  $data=array('uemail'=>$this->input->post('email'));
  $count=$this->AM->checkDuplicateCount($data);
  if($count>0){
     $message['exist']='yes';

   }else{
    $message['exist']='no';
  }

echo json_encode($message);
}

public function error(){
  $this->db->view('error');

}



}



?>
